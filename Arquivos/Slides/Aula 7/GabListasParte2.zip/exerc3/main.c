#include <stdio.h>
#include <stdlib.h>
#include "exercicio.h"

int main()
{
	Lista* l;
	printf ("\nCriando lista....");
	l = lst_cria();
	printf ("\nInserindo elementos na lista....\n");
	l = lst_insere (l, 1);
	l = lst_insere (l, 5);
	l = lst_insere (l, 2);
	l = lst_insere (l, 3);
	printf ("\nImprimindo lista....\n");
	lst_imprime (l);
	if (l!=NULL)//ha elementos na lista
	{
		printf ("\nCalculando media...");
		float media = lst_calculaMedia (l);
		printf ("\nA media eh %.2f\n", media);
	}
	system("PAUSE");
	return 1;
}