#include <stdio.h>
#include <stdlib.h>
#include "exercicio.h"

int main()
{
	Lista* l;
	printf ("\nCriando lista....");
	l = lst_cria();
	printf ("\nInserindo elementos na lista....");
	l = lst_insere (l, 50);
	l = lst_insere (l, -40);
	l = lst_insere (l, 30);
	l = lst_insere (l, -20);
	l = lst_insere (l, 10);
	printf ("\nImprimindo lista....\n");
	lst_imprime (l);
	printf ("\nAlterando sinal da lista...");
	lst_altera (l);
	printf ("\nImprimindo lista novamente....\n");
	lst_imprime (l);
	lst_libera (l);
	system("PAUSE");
	return 1;
}