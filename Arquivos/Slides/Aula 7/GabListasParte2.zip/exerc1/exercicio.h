struct lista
{
	int info;
	struct lista* prox;
};
typedef struct lista Lista;

Lista* lst_cria (void);
Lista* lst_insere (Lista* l, int v);
void lst_imprime (Lista* l);
void lst_altera (Lista* l);
void lst_libera (Lista* l);