#include <stdio.h>
#include <stdlib.h>
#include "exercicio.h"

int main()
{
	Lista* l;
	printf ("\nCriando lista....");
	l = lst_cria();
	printf ("\nImprimindo lista....\n");
	lst_imprime (l);
	printf ("\nInserindo elementos na lista....");
	l = lst_insere (l, 10);
	printf ("\nImprimindo lista....\n");
	lst_imprime (l);
	l = lst_insere (l, 20);
	printf ("\nImprimindo lista....\n");
	lst_imprime (l);
	l = lst_insere (l, 30);
	printf ("\nImprimindo lista....\n");
	lst_imprime (l);
	l = lst_insere (l, 40);
	printf ("\nImprimindo lista....\n");
	lst_imprime (l);
	l = lst_insere (l, 50);
	printf ("\nImprimindo lista....\n");
	lst_imprime (l);
	system("PAUSE");
	return 1;
}