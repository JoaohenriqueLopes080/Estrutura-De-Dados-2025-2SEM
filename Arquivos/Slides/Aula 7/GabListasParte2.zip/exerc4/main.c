#include <stdio.h>
#include <stdlib.h>
#include "exercicio.h"

int main()
{
	Lista* l;
	printf ("\nCriando lista....");
	l = lst_cria();
	printf ("\nInserindo elementos na lista....");
	l = lst_insere (l, 50);
	l = lst_insere (l, 40);
	l = lst_insere (l, 30);
	l = lst_insere (l, 20);
	l = lst_insere (l, 10);
	printf ("\nImprimindo lista....\n");
	lst_imprime (l);
	int elemento;
	printf ("\nDigite o valor do elemento a ser considerado: ");
	scanf ("%d", &elemento);
	printf ("\nTentando remover o noh anterior ao elemento %d... \n", elemento);
	l = lst_retira_ant (l, elemento);
	printf ("\nImprimindo lista novamente....\n");
	lst_imprime (l);
	system("PAUSE");
	return 1;
}