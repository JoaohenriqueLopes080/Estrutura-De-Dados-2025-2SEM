#include "exercicio.h"
#include <stdio.h>
#include <stdlib.h>

/* função de criação: retorna uma lista vazia */
Lista* lst_cria (void)
{
	return NULL;
}

/* função imprime: imprime valores dos elementos */
void lst_imprime (Lista* l)
{
	Lista* p;
	for (p = l; p != NULL; p = p->prox)
		printf("info = %d\n", p->info);
}

void lst_libera (Lista* l)
{
	Lista* p = l;
	while (p != NULL) {
		l = p->prox; /* guarda referência p/ próx. elemento */
		free(p); /* libera a memória apontada por p */
	p = l; /* faz p apontar para o próximo */
	}
}

Lista* ultimo (Lista* l)
{
	Lista* p=l;
	if (p!=NULL)
		while (p->prox!=NULL)
			p=p->prox;
	return p;
}

/* inserção no fim: retorna a lista atualizada */
Lista* lst_insere (Lista* l, int i)
{
	Lista* novo = (Lista*) malloc(sizeof(Lista));
	novo->info = i;
	novo->prox=NULL;
	Lista* ult = ultimo (l);
	if (ult==NULL)//lista vazia
		l=novo;
	else //ha elementos na lista
		ult->prox=novo;
	return l;
}

/* função retira: retira elemento da lista */
Lista* lst_retira (Lista* l, int v)
{
	Lista* ant = NULL; /* ponteiro para elemento anterior */
	Lista* p = l; /* ponteiro para percorrer a lista */
	/* procura elemento na lista, guardando anterior */
	while (p != NULL && p->info != v)
	{
		ant = p;
		p = p->prox;
	}
	/* verifica se achou elemento */
	if (p == NULL)
		return l; /* não achou: retorna lista original */
	/* retira elemento */
	if (ant == NULL)
		l = p->prox;
	else
		ant->prox = p->prox;
	free(p);
	return l;
}

/* função retira: retira elemento anterior da lista */
Lista* lst_retira_ant (Lista* l, int v)
{
	Lista* p = l; /* ponteiro para percorrer a lista */
	if (p==NULL || p->info==v) //lista estah vazia ou quer remover o nó anterior ao inicio
	{
		printf ("\nRemocao nao serah realizada, retorna lista original....");
		return l;
	}
	Lista* ant = NULL;
	while (p!=NULL && p->info!=v)//procura elemento
	{
		ant=p;
		p=p->prox;
	}
	if (p!=NULL)//encontrou o valor v passado em p, logo remove o anterior a ele
	{
		printf ("\nVai remover o valor %d", ant->info);
		l=lst_retira(l, ant->info);//manda remover o anterior ao valor passado
   }
	return l;		
}