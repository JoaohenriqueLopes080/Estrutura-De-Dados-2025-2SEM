struct lista
{
	int info;
	struct lista* prox;
};
typedef struct lista Lista;

Lista* lst_cria (void);
Lista* lst_insere (Lista* l, int v);
void lst_imprime (Lista* l);
void lst_libera (Lista* l);
Lista* lst_retira (Lista* l, int v);
Lista* lst_retira_ant (Lista* l, int v);