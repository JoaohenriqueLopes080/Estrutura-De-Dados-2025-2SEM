#include <stdio.h>
#include <stdlib.h>

int dentro_ret (int x0, int y0, int x1, int y1, int x, int y);
void le_pontos (int *x0, int *y0, int *x1, int *y1, int *x, int *y);
void imprime_saida (int retorno);

int main()
{
	int x0, y0, x1, y1, x, y, retorno;
	while (1)
	{
		le_pontos (&x0, &y0, &x1, &y1, &x, &y); //passa o endereco das variaveis
		retorno=dentro_ret(x0, y0, x1, y1, x, y);
		imprime_saida (retorno);
	}//while
	system("pause");
}

void le_pontos (int* a, int *b, int *c, int *d, int *e, int *f)
{
	printf ("\n\n\nInforme o ponto inferior esquerdo do ret (x,y): ");
	scanf ("%d %d", a, b);
	printf ("\nInforme o ponto superior direito do ret (x,y): ");
	scanf ("%d %d", c, d);
	printf ("\nInforme o pto a verificar (x,y): ");
	scanf ("%d %d", e, f);
}

int dentro_ret(int x0,int y0,int x1,int y1,int x,int y)
{
	if (x>=x0 && x<=x1 && y>=y0 && y<=y1)
		return 1;
	else
	return 0;
}

void imprime_saida (int retorno)
{
	if (retorno==1)
		printf ("\n\t** Pto ESTAH dentro do retangulo");
	else
		printf ("\n\t** Pto NAO estah dentro do retangulo");

}
