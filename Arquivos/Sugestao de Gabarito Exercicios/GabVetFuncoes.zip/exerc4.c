#include <stdio.h>
#include <stdlib.h>

void escreve (int tamanho, int* vet)
{
	int i;
	for (i=tamanho-1;i>=0; i--)
	printf ("\nImprimindo ao contrario: %d ", vet[i]);
}

int* aloca_vetor (int tamanho)
{
	int* vet=(int*)(malloc(tamanho*sizeof(int)));
	if(vet==NULL)
	{
		printf ("\nErro na alocacao de memoria\n");
		system("pause");
		exit(1);
	}
	return vet;
}

void preenche_vetor (int tamanho, int* vet)
{
	int i;
	for (i=0;i<tamanho;i++)
	{
		printf ("\nInforme o valor do vetor [%d]: ", i);
		scanf ("%d", &vet[i]);
	}
}	

int main()
{
	int i, tamanho=10;
	int* vet = aloca_vetor (tamanho);
	preenche_vetor (tamanho, vet);
	escreve (tamanho, vet);
	free (vet);
	system ("pause");
}


