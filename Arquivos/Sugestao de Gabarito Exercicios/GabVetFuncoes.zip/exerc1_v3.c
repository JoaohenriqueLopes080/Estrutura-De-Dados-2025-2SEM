#include <stdio.h>
#include <stdlib.h>

//define um tipo Ponto
struct ponto
{
	int x;
	int y;
};
typedef struct ponto Ponto;

int dentro_ret (int x0, int y0, int x1, int y1, int x, int y);
Ponto le_ponto (void);
void imprime_saida (int retorno);

int main()
{
	Ponto A, B, C;
	int retorno;
	while (1)
	{
		//le os 3 pontos
		A = le_ponto();
		B = le_ponto();
		C = le_ponto();		
		retorno=dentro_ret(A.x, A.y, B.x, B.y, C.x, C.y);//poderia passar os 3 ptos ao inves das 6 coordenadas
		imprime_saida (retorno);
	}//while
	system("pause");
}

Ponto le_ponto ()
{
	Ponto X;
	printf ("\nDigite as 2 coordenadas: ");
	scanf ("%d %d", &X.x, &X.y);
	return X;
}

int dentro_ret(int x0,int y0,int x1,int y1,int x,int y)
{
	if (x>=x0 && x<=x1 && y>=y0 && y<=y1)
		return 1;
	else
		return 0;
}

void imprime_saida (int retorno)
{
	if (retorno==1)
		printf ("\n\t** Pto ESTAH dentro do retangulo");
	else
		printf ("\n\t** Pto NAO estah dentro do retangulo");

}
