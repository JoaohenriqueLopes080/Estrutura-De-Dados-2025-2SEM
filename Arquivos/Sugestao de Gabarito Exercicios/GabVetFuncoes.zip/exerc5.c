#include <stdio.h>
#include <stdlib.h>

int le_tamanho (void)
{
	int tamanho;
	printf ("\nInforme o tamanho do vetor: ");
	scanf ("%d", &tamanho);
	return tamanho;
}

float* aloca_vetor (int tamanho)
{
	float* vet=(float*)(malloc(10*sizeof(float)));
	if(vet==NULL)
	{
		printf ("\nErro na alocacao de memoria\n");
		system("pause");
		exit(1);
	}
	return vet;
}

void le_vetor (int tamanho, float* vet)
{
	int i;
	for (i=0;i<tamanho;i++)
	{
		printf ("\nInforme o vet[%d]: ",i);
		scanf ("%f", &vet[i]);
	}	
}

float calcula_media (int tamanho, float* vet)
{
	int i;
	float soma=0;
	for (i=0;i<tamanho;i++)
		soma+=vet[i];
	return (soma/tamanho);
}

float calcula_perc (int tamanho, float* vet, float media)
{
	int i, cont=0;
	for (i=0;i<tamanho;i++)
		if (vet[i]>media)
			cont++;
	float perc = (float)cont*100/tamanho;
	return perc;
}

int main()
{
	int tamanho;
	float* vet;
	tamanho = le_tamanho ();
	vet = aloca_vetor (tamanho);
	le_vetor(tamanho, vet);
	float media = calcula_media (tamanho, vet);
	printf ("\nA media eh %.2f", media);
	float perc = calcula_perc(tamanho, vet, media);
	printf ("\nO percentual de numeros maiores que a media eh %.2f\n", perc);
	free(vet);
	system ("pause");
}
