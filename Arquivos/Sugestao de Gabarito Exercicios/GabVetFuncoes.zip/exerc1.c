#include <stdio.h>
#include <stdlib.h>

int dentro_ret (int x0, int y0, int x1, int y1, int x, int y);
void le_pontos (int *x0, int *y0, int *x1, int *y1, int *x, int *y);
void imprime_saida (int retorno);

int lePonto(char* msg){
   int x;
   printf("%s", msg);
   scanf("%d", &x);
   return x;
}

int main()
{
	int x0, y0, x1, y1, x, y, retorno;
	while (1)
	{   
		//chama 6x a funcao lePonto
		x0 = lePonto("\nInforme x do pto inferior esquerdo do ret(x,y):");
		y0 = lePonto("Informe y do pto inferior esquerdo do ret(x,y):");
		x1 = lePonto("Informe x do pto superior direito do ret(x,y):");
		y1 = lePonto("Informe y do pto superior direito do ret(x,y):");
		x = lePonto("Informe x do pto:");
		y = lePonto("Informe y do pto:");			
		retorno=dentro_ret(x0, y0, x1, y1, x, y);
		imprime_saida (retorno);
	}//while
	system("pause");
}

int dentro_ret(int x0,int y0,int x1,int y1,int x,int y)
{
	if (x>=x0 && x<=x1 && y>=y0 && y<=y1)
		return 1;
	else
	return 0;
}

void imprime_saida (int retorno)
{
	if (retorno==1)
		printf ("\n\t** Pto ESTAH dentro do retangulo");
	else
		printf ("\n\t** Pto NAO estah dentro do retangulo");

}
